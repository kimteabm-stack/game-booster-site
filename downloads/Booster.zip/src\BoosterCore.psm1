﻿Set-StrictMode -Version 2.0

try {
    Add-Type -Namespace BoosterNative -Name Shell -MemberDefinition @'
[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);
'@ -ErrorAction Stop
} catch {
}

function Send-BoosterUiSettingChangeBroadcast {
    try {
        $hwndBroadcast = [IntPtr]0xffff
        $wmSettingChange = 0x001A
        $smtoAbortIfHung = 0x0002
        $result = [UIntPtr]::Zero
        [void][BoosterNative.Shell]::SendMessageTimeout($hwndBroadcast, $wmSettingChange, [UIntPtr]::Zero, 'General', $smtoAbortIfHung, 2000, [ref]$result)
    } catch {
    }
}

# Standby-list purge via NtSetSystemInformation(SystemMemoryListInformation).
# Enum order/values verified against System Informer's phnt/ntexapi.h (the canonical reference
# for this undocumented NT API) - several blog copies of this code have the enum shifted by one.
function Initialize-BoosterMemoryNative {
    if ('BoosterMemory' -as [type]) {
        return
    }

    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class BoosterMemory
{
    private const string SE_PROFILE_SINGLE_PROCESS_NAME = "SeProfileSingleProcessPrivilege";
    private const uint SE_PRIVILEGE_ENABLED = 0x00000002;
    private const int SystemMemoryListInformation = 80;
    private const uint TOKEN_ADJUST_PRIVILEGES = 0x0020;
    private const uint TOKEN_QUERY = 0x0008;

    private enum SYSTEM_MEMORY_LIST_COMMAND
    {
        MemoryCaptureAccessedBits = 0,
        MemoryCaptureAndResetAccessedBits = 1,
        MemoryEmptyWorkingSets = 2,
        MemoryFlushModifiedList = 3,
        MemoryPurgeStandbyList = 4,
        MemoryPurgeLowPriorityStandbyList = 5
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct LUID
    {
        public uint LowPart;
        public int HighPart;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct TOKEN_PRIVILEGES
    {
        public uint PrivilegeCount;
        public LUID Luid;
        public uint Attributes;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out LUID lpLuid);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool AdjustTokenPrivileges(IntPtr TokenHandle, bool DisableAllPrivileges, ref TOKEN_PRIVILEGES NewState, uint BufferLength, IntPtr PreviousState, IntPtr ReturnLength);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr hObject);

    [DllImport("ntdll.dll")]
    private static extern uint NtSetSystemInformation(int SystemInformationClass, ref int SystemInformation, uint SystemInformationLength);

    private static bool EnableProfileSingleProcessPrivilege()
    {
        IntPtr tokenHandle;
        if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, out tokenHandle))
        {
            return false;
        }

        try
        {
            LUID luid;
            if (!LookupPrivilegeValue(null, SE_PROFILE_SINGLE_PROCESS_NAME, out luid))
            {
                return false;
            }

            TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
            tp.PrivilegeCount = 1;
            tp.Luid = luid;
            tp.Attributes = SE_PRIVILEGE_ENABLED;

            return AdjustTokenPrivileges(tokenHandle, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
        }
        finally
        {
            CloseHandle(tokenHandle);
        }
    }

    public static bool PurgeStandbyList()
    {
        if (!EnableProfileSingleProcessPrivilege())
        {
            return false;
        }

        int emptyWorkingSets = (int)SYSTEM_MEMORY_LIST_COMMAND.MemoryEmptyWorkingSets;
        int flushModifiedList = (int)SYSTEM_MEMORY_LIST_COMMAND.MemoryFlushModifiedList;
        int purgeStandby = (int)SYSTEM_MEMORY_LIST_COMMAND.MemoryPurgeStandbyList;

        NtSetSystemInformation(SystemMemoryListInformation, ref emptyWorkingSets, 4);
        NtSetSystemInformation(SystemMemoryListInformation, ref flushModifiedList, 4);
        uint status = NtSetSystemInformation(SystemMemoryListInformation, ref purgeStandby, 4);

        return status == 0;
    }
}
'@
}

function Clear-BoosterStandbyMemory {
    try {
        Initialize-BoosterMemoryNative

        $before = $null
        try {
            $before = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).FreePhysicalMemory
        } catch {
        }

        $success = [BoosterMemory]::PurgeStandbyList()

        $freedMb = 0
        if ($success -and $null -ne $before) {
            try {
                $after = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).FreePhysicalMemory
                if ($after -gt $before) {
                    $freedMb = [math]::Round(($after - $before) / 1024, 0)
                }
            } catch {
            }
        }

        [pscustomobject]@{
            Success = [bool]$success
            FreedMb = [int]$freedMb
        }
    } catch {
        [pscustomobject]@{
            Success = $false
            FreedMb = 0
        }
    }
}

function Invoke-BoosterRouteTrace {
    param(
        [Parameter(Mandatory = $true)]
        [string]$TargetHost,
        [int]$MaxHops = 16,
        [int]$TimeoutMs = 800
    )

    $hops = @()
    try {
        $ping = New-Object System.Net.NetworkInformation.Ping
        $buffer = [System.Text.Encoding]::ASCII.GetBytes('boosterroutecheck')

        for ($ttl = 1; $ttl -le $MaxHops; $ttl++) {
            $options = New-Object System.Net.NetworkInformation.PingOptions ($ttl, $true)
            $reply = $null
            try {
                $reply = $ping.Send($TargetHost, $TimeoutMs, $buffer, $options)
            } catch {
                $hops += [pscustomobject]@{ Hop = $ttl; Address = $null; Ms = $null }
                continue
            }

            $address = if ($reply -and $reply.Address) { $reply.Address.ToString() } else { $null }
            $isTimedTransit = $reply -and $reply.Status -eq [System.Net.NetworkInformation.IPStatus]::TtlExpired
            $isDone = $reply -and $reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success
            $ms = if ($isTimedTransit -or $isDone) { [int]$reply.RoundtripTime } else { $null }

            $hops += [pscustomobject]@{ Hop = $ttl; Address = $address; Ms = $ms }

            if ($isDone) {
                break
            }
        }
    } catch {
    }

    return @($hops)
}

function Get-BoosterRouteDiagnosisSummary {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Hops,
        [int]$JumpThresholdMs = 40
    )

    $validHops = @($Hops | Where-Object { $null -ne $_.Ms })
    if ((Get-BoosterItemCount -Value $validHops) -lt 2) {
        return [pscustomobject]@{
            HasBigJump = $false
            JumpHop = $null
            JumpDelta = 0
            FinalMs = if ((Get-BoosterItemCount -Value $validHops) -gt 0) { $validHops[-1].Ms } else { $null }
        }
    }

    $maxDelta = 0
    $jumpHop = $null
    for ($i = 1; $i -lt $validHops.Count; $i++) {
        $delta = [int]$validHops[$i].Ms - [int]$validHops[$i - 1].Ms
        if ($delta -gt $maxDelta) {
            $maxDelta = $delta
            $jumpHop = $validHops[$i]
        }
    }

    [pscustomobject]@{
        HasBigJump = ($maxDelta -ge $JumpThresholdMs)
        JumpHop = $jumpHop
        JumpDelta = $maxDelta
        FinalMs = $validHops[-1].Ms
    }
}

function Get-BoosterRoot {
    Split-Path -Parent $PSScriptRoot
}

function Get-BoosterConfigPath {
    param(
        [string]$Path
    )

    if ($Path) {
        return (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
    }

    return (Join-Path (Get-BoosterRoot) 'config\booster.config.json')
}

function Read-BoosterConfig {
    param(
        [string]$Path
    )

    $configPath = Get-BoosterConfigPath -Path $Path
    if (-not (Test-Path -LiteralPath $configPath)) {
        throw "Config file not found: $configPath"
    }

    $raw = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8
    $config = $raw | ConvertFrom-Json
    $config | Add-Member -NotePropertyName ConfigPath -NotePropertyValue $configPath -Force
    return $config
}

function New-BoosterState {
    [pscustomobject]@{
        Active = $false
        ProfileId = $null
        ProfileName = $null
        ActiveProcessKeys = @{}
        LastSummary = $null
        StartedAt = $null
        OriginalPowerSchemeGuid = $null
        OriginalPowerSchemeName = $null
        OriginalNetworkSettings = @()
        OriginalAdapterSettings = @()
        OriginalEeeSettings = @()
        OriginalInterruptModerationSettings = @()
        OriginalQosPacketSchedulerSettings = @()
        OriginalFlowControlSettings = @()
        OriginalIPv6PreferenceSettings = @()
        OriginalGameBarSettings = @()
        OriginalAnimationSettings = @()
        OriginalDnsSettings = @()
        OriginalRscSettings = @()
        OriginalTcpInterfaceSettings = @()
        OriginalNetworkServiceStates = @()
        DisabledNetworkAdapters = @()
        GameQosPolicies = @()
        BackgroundQosPolicies = @()
        NetworkOptimized = $false
        LoweredPriorities = @{}
        LastMessages = @()
    }
}

function ConvertTo-BoosterArray {
    param(
        [object]$Value
    )

    if ($null -eq $Value) {
        return @()
    }

    return @($Value)
}

function Get-BoosterItemCount {
    param(
        [object]$Value
    )

    if ($null -eq $Value) {
        return 0
    }

    return @($Value).Count
}

function Normalize-BoosterProcessName {
    param(
        [string]$Name
    )

    if (-not $Name) {
        return $null
    }

    return [System.IO.Path]::GetFileNameWithoutExtension($Name.Trim())
}

function Initialize-BoosterWin32 {
    if ('BoosterWin32' -as [type]) {
        return
    }

    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class BoosterWin32
{
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern int GetWindowTextLength(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
}
'@
}

function Get-BoosterPropertyValue {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Object,
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) {
        return $null
    }

    return $property.Value
}

function Get-BoosterProfileKey {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Profile
    )

    $id = Get-BoosterPropertyValue -Object $Profile -Name 'id'
    if ($id) {
        return [string]$id
    }

    return [string](Get-BoosterPropertyValue -Object $Profile -Name 'name')
}

function Get-BoosterProfileMatchForProcess {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process]$Process
    )

    foreach ($profile in (ConvertTo-BoosterArray $Config.profiles)) {
        foreach ($rawName in (ConvertTo-BoosterArray $profile.processNames)) {
            $processName = Normalize-BoosterProcessName $rawName
            if (-not $processName) {
                continue
            }

            if ($processName -ieq $Process.ProcessName -and (Test-BoosterProcessMatchesProfile -Process $Process -Profile $profile)) {
                return $profile
            }
        }
    }

    return $null
}

function Find-BoosterProfile {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [string]$ProfileKey
    )

    foreach ($profile in (ConvertTo-BoosterArray $Config.profiles)) {
        if ((Get-BoosterProfileKey -Profile $profile) -eq $ProfileKey) {
            return $profile
        }

        $name = Get-BoosterPropertyValue -Object $profile -Name 'name'
        if ($name -and [string]$name -eq $ProfileKey) {
            return $profile
        }
    }

    return $null
}

function Get-BoosterProcessCommandLine {
    param(
        [Parameter(Mandatory = $true)]
        [int]$ProcessId
    )

    try {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId = $ProcessId" -ErrorAction Stop
        return [string]$process.CommandLine
    } catch {
        try {
            $process = Get-WmiObject Win32_Process -Filter "ProcessId = $ProcessId" -ErrorAction Stop
            return [string]$process.CommandLine
        } catch {
            return ''
        }
    }
}

function Test-BoosterKeywordMatch {
    param(
        [string]$Text,
        [object]$Keywords
    )

    if (-not $Text) {
        return $false
    }

    foreach ($keyword in (ConvertTo-BoosterArray $Keywords)) {
        if ($keyword -and $Text.IndexOf([string]$keyword, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            return $true
        }
    }

    return $false
}

function Test-BoosterProcessMatchesProfile {
    param(
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process]$Process,
        [Parameter(Mandatory = $true)]
        [object]$Profile
    )

    $titleKeywords = Get-BoosterPropertyValue -Object $Profile -Name 'windowTitleKeywords'
    $commandLineKeywords = Get-BoosterPropertyValue -Object $Profile -Name 'commandLineKeywords'
    $hasTitleFilter = (Get-BoosterItemCount -Value @(ConvertTo-BoosterArray $titleKeywords)) -gt 0
    $hasCommandLineFilter = (Get-BoosterItemCount -Value @(ConvertTo-BoosterArray $commandLineKeywords)) -gt 0

    if (-not $hasTitleFilter -and -not $hasCommandLineFilter) {
        return $true
    }

    $title = ''
    try {
        $title = [string]$Process.MainWindowTitle
    } catch {
    }

    if ($hasTitleFilter -and (Test-BoosterKeywordMatch -Text $title -Keywords $titleKeywords)) {
        return $true
    }

    if ($hasCommandLineFilter) {
        $commandLine = Get-BoosterProcessCommandLine -ProcessId $Process.Id
        if (Test-BoosterKeywordMatch -Text $commandLine -Keywords $commandLineKeywords) {
            return $true
        }
    }

    return $false
}

function Get-BoosterWindowCandidateScore {
    param(
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process]$Process,
        [string]$Title,
        [string]$ExecutablePath,
        [string]$CommandLine,
        [object]$MatchedProfile
    )

    $score = 10
    $hint = 'Open window'
    $text = (($Title + ' ' + $Process.ProcessName + ' ' + $ExecutablePath + ' ' + $CommandLine)).ToLowerInvariant()

    if ($MatchedProfile) {
        return [pscustomobject]@{
            Score = 120
            Hint = 'Registered game'
        }
    }

    if ($text -match 'steamapps[\\/]+common') {
        $score += 80
        $hint = 'Steam game'
    } elseif ($text -match 'epic games|epicgames') {
        $score += 70
        $hint = 'Epic game'
    } elseif ($text -match 'xboxgames|windowsapps') {
        $score += 55
        $hint = 'Store/Xbox game'
    }

    if ($text -match 'roblox|minecraft|elden ring|eldenring|limbus|limbuscompany|projectmoon') {
        $score += 80
        $hint = 'Known game'
    }

    if ($Process.ProcessName -ieq 'javaw' -and $text -match 'minecraft|\.minecraft') {
        $score += 70
        $hint = 'Minecraft Java'
    }

    [pscustomobject]@{
        Score = $score
        Hint = $hint
    }
}

function Test-BoosterWindowCandidateExcluded {
    param(
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process]$Process,
        [string]$Title,
        [switch]$AllowUtilityApps
    )

    if ($Process.Id -eq $PID) {
        return $true
    }

    $processName = $Process.ProcessName.ToLowerInvariant()

    # Shell/system processes: can never be an optimization target, whether auto-detected or manually picked
    $alwaysExcludedProcesses = @(
        'booster',
        'cmd',
        'codex',
        'conhost',
        'dwm',
        'explorer',
        'lockapp',
        'powershell',
        'pwsh',
        'searchapp',
        'searchhost',
        'shellexperiencehost',
        'startmenuexperiencehost',
        'systemsettings',
        'taskhostw',
        'textinputhost',
        'windowsterminal'
    )

    if ($alwaysExcludedProcesses -contains $processName) {
        return $true
    }

    # Browsers/messaging apps: excluded from auto-detect so they're not mistaken for a game,
    # but must still be manually selectable for watching YouTube/Netflix etc. (-AllowUtilityApps)
    if (-not $AllowUtilityApps) {
        $utilityProcesses = @(
            'chatgpt',
            'chrome',
            'claude',
            'discord',
            'firefox',
            'msedge',
            'msteams',
            'notion',
            'slack',
            'teams'
        )

        if ($utilityProcesses -contains $processName) {
            return $true
        }
    }

    if ($Title -match '^\s*$|^Program Manager$') {
        return $true
    }

    return $false
}

function Get-BoosterWindowCandidateFromHandle {
    param(
        [Parameter(Mandatory = $true)]
        [IntPtr]$WindowHandle,
        [object]$Config
    )

    Initialize-BoosterWin32

    if ($WindowHandle -eq [IntPtr]::Zero) {
        return $null
    }

    if (-not [BoosterWin32]::IsWindowVisible($WindowHandle)) {
        return $null
    }

    $length = [BoosterWin32]::GetWindowTextLength($WindowHandle)
    if ($length -le 0) {
        return $null
    }

    $builder = New-Object System.Text.StringBuilder ($length + 1)
    [void][BoosterWin32]::GetWindowText($WindowHandle, $builder, $builder.Capacity)
    $title = $builder.ToString().Trim()
    if (-not $title) {
        return $null
    }

    [uint32]$processId = 0
    [void][BoosterWin32]::GetWindowThreadProcessId($WindowHandle, [ref]$processId)
    if ($processId -le 0) {
        return $null
    }

    try {
        $process = Get-Process -Id ([int]$processId) -ErrorAction Stop
    } catch {
        return $null
    }

    if (Test-BoosterWindowCandidateExcluded -Process $process -Title $title) {
        return $null
    }

    $exePath = Resolve-BoosterProcessPath -Process $process
    $commandLine = Get-BoosterProcessCommandLine -ProcessId ([int]$processId)
    $matchedProfile = if ($Config) { Get-BoosterProfileMatchForProcess -Config $Config -Process $process } else { $null }
    $score = Get-BoosterWindowCandidateScore -Process $process -Title $title -ExecutablePath $exePath -CommandLine $commandLine -MatchedProfile $matchedProfile
    $displayName = if ($matchedProfile) { [string](Get-BoosterPropertyValue -Object $matchedProfile -Name 'name') } else { $title }
    $profileKey = if ($matchedProfile) { Get-BoosterProfileKey -Profile $matchedProfile } else { $null }

    [pscustomobject]@{
        DisplayName = $displayName
        Title = $title
        ProcessId = [int]$processId
        ProcessName = $process.ProcessName
        ExecutablePath = $exePath
        CommandLine = $commandLine
        Hint = $score.Hint
        Score = [int]$score.Score
        ProfileKey = $profileKey
    }
}

function Get-BoosterForegroundWindowCandidate {
    param(
        [object]$Config
    )

    Initialize-BoosterWin32
    $windowHandle = [BoosterWin32]::GetForegroundWindow()
    return Get-BoosterWindowCandidateFromHandle -WindowHandle $windowHandle -Config $Config
}

function Get-BoosterWindowCandidates {
    param(
        [object]$Config
    )

    Initialize-BoosterWin32

    $windows = New-Object System.Collections.ArrayList
    $seenProcessIds = @{}

    $callback = [BoosterWin32+EnumWindowsProc]{
        param(
            [IntPtr]$WindowHandle,
            [IntPtr]$Param
        )

        if (-not [BoosterWin32]::IsWindowVisible($WindowHandle)) {
            return $true
        }

        $length = [BoosterWin32]::GetWindowTextLength($WindowHandle)
        if ($length -le 0) {
            return $true
        }

        $builder = New-Object System.Text.StringBuilder ($length + 1)
        [void][BoosterWin32]::GetWindowText($WindowHandle, $builder, $builder.Capacity)
        $title = $builder.ToString().Trim()
        if (-not $title) {
            return $true
        }

        [uint32]$processId = 0
        [void][BoosterWin32]::GetWindowThreadProcessId($WindowHandle, [ref]$processId)
        if ($processId -le 0 -or $seenProcessIds.ContainsKey([string]$processId)) {
            return $true
        }

        try {
            $process = Get-Process -Id ([int]$processId) -ErrorAction Stop
        } catch {
            return $true
        }

        if (Test-BoosterWindowCandidateExcluded -Process $process -Title $title -AllowUtilityApps) {
            return $true
        }

        $seenProcessIds[[string]$processId] = $true
        $exePath = Resolve-BoosterProcessPath -Process $process
        $commandLine = Get-BoosterProcessCommandLine -ProcessId ([int]$processId)
        $matchedProfile = if ($Config) { Get-BoosterProfileMatchForProcess -Config $Config -Process $process } else { $null }
        $score = Get-BoosterWindowCandidateScore -Process $process -Title $title -ExecutablePath $exePath -CommandLine $commandLine -MatchedProfile $matchedProfile
        $displayName = if ($matchedProfile) { [string](Get-BoosterPropertyValue -Object $matchedProfile -Name 'name') } else { $title }
        $profileKey = if ($matchedProfile) { Get-BoosterProfileKey -Profile $matchedProfile } else { $null }

        [void]$windows.Add([pscustomobject]@{
            DisplayName = $displayName
            Title = $title
            ProcessId = [int]$processId
            ProcessName = $process.ProcessName
            ExecutablePath = $exePath
            CommandLine = $commandLine
            Hint = $score.Hint
            Score = [int]$score.Score
            ProfileKey = $profileKey
        })

        return $true
    }

    [void][BoosterWin32]::EnumWindows($callback, [IntPtr]::Zero)

    return @($windows | Sort-Object -Property @{ Expression = 'Score'; Descending = $true }, @{ Expression = 'DisplayName'; Descending = $false })
}

function Get-BoosterProfileProcesses {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Profile
    )

    $profileProcesses = @()
    $seen = @{}
    foreach ($rawName in (ConvertTo-BoosterArray $Profile.processNames)) {
        $processName = Normalize-BoosterProcessName $rawName
        if (-not $processName) {
            continue
        }

        foreach ($process in @(Get-Process -Name $processName -ErrorAction SilentlyContinue)) {
            if ($seen.ContainsKey([string]$process.Id)) {
                continue
            }

            if (Test-BoosterProcessMatchesProfile -Process $process -Profile $Profile) {
                $seen[[string]$process.Id] = $true
                $profileProcesses += $process
            }
        }
    }

    return $profileProcesses
}

function Get-BoosterRunningProfile {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config
    )

    foreach ($profile in (ConvertTo-BoosterArray $Config.profiles)) {
        $profileProcesses = @(Get-BoosterProfileProcesses -Profile $profile)

        if ((Get-BoosterItemCount -Value $profileProcesses) -gt 0) {
            return [pscustomobject]@{
                Profile = $profile
                Processes = $profileProcesses
            }
        }
    }

    return $null
}

function Get-BoosterActivePowerScheme {
    $output = & powercfg /getactivescheme 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "powercfg failed: $output"
    }

    $text = ($output | Out-String).Trim()
    $guidMatch = [regex]::Match($text, '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')
    $nameMatch = [regex]::Match($text, '\((?<name>[^)]+)\)')

    [pscustomobject]@{
        Guid = if ($guidMatch.Success) { $guidMatch.Value } else { $null }
        Name = if ($nameMatch.Success) { $nameMatch.Groups['name'].Value } else { $null }
        Raw = $text
    }
}

function Set-BoosterPowerScheme {
    param(
        [ValidateSet('HighPerformance', 'Balanced')]
        [string]$Scheme
    )

    $alias = if ($Scheme -eq 'HighPerformance') { 'SCHEME_MIN' } else { 'SCHEME_BALANCED' }
    $output = & powercfg /setactive $alias 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to switch power plan to ${Scheme}: $output"
    }
}

function Restore-BoosterPowerScheme {
    param(
        [string]$Guid
    )

    if (-not $Guid) {
        return $false
    }

    $output = & powercfg /setactive $Guid 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to restore power plan ${Guid}: $output"
    }

    return $true
}

function Ensure-BoosterStateProperty {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [object]$DefaultValue
    )

    if (-not $State.PSObject.Properties[$Name]) {
        $State | Add-Member -NotePropertyName $Name -NotePropertyValue $DefaultValue -Force
    }
}

function Get-BoosterConfigBool {
    param(
        [object]$Config,
        [string]$Name,
        [bool]$Fallback
    )

    if (-not $Config) {
        return $Fallback
    }

    $property = $Config.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        return $Fallback
    }

    return [bool]$property.Value
}

function Get-BoosterConfigInt {
    param(
        [object]$Config,
        [string]$Name,
        [int]$Fallback
    )

    if (-not $Config) {
        return $Fallback
    }

    $property = $Config.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        return $Fallback
    }

    try {
        return [int]$property.Value
    } catch {
        return $Fallback
    }
}

function Get-BoosterConfigArray {
    param(
        [object]$Config,
        [string]$Name,
        [object[]]$Fallback
    )

    if (-not $Config) {
        return @($Fallback)
    }

    $property = $Config.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        return @($Fallback)
    }

    return @(ConvertTo-BoosterArray $property.Value)
}

function ConvertTo-BoosterUInt32 {
    param(
        [object]$Value
    )

    if ($null -eq $Value) {
        return $null
    }

    try {
        return [uint32]$Value
    } catch {
        try {
            return [uint32]([int64]$Value -band 0xffffffff)
        } catch {
            return $null
        }
    }
}

function Get-BoosterRegistryValueSnapshot {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    $property = $null
    if (Test-Path -LiteralPath $Path) {
        try {
            $item = Get-ItemProperty -LiteralPath $Path -ErrorAction Stop
            $property = $item.PSObject.Properties[$Name]
        } catch {
        }
    }

    [pscustomobject]@{
        Path = $Path
        Name = $Name
        Existed = ($null -ne $property)
        Value = if ($property) { $property.Value } else { $null }
    }
}

function Set-BoosterWifiLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalAdapterSettings' -DefaultValue @()
    $messages = @()
    $changedCount = 0

    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object {
        $_.Status -eq 'Up' -and ($_.MediaType -eq 'Native 802.11' -or $_.InterfaceDescription -match 'Wireless|Wi-Fi|802\.11')
    })

    foreach ($adapter in $adapters) {
        try {
            $property = Get-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword 'RegROAMSensitiveLevel' -ErrorAction Stop
            if ((Get-BoosterItemCount -Value $property) -lt 1) {
                continue
            }

            $alreadySaved = @($State.OriginalAdapterSettings | Where-Object {
                $_.Name -eq $adapter.Name -and $_.RegistryKeyword -eq 'RegROAMSensitiveLevel'
            })
            if ((Get-BoosterItemCount -Value $alreadySaved) -lt 1) {
                $State.OriginalAdapterSettings += [pscustomobject]@{
                    Name = [string]$adapter.Name
                    RegistryKeyword = 'RegROAMSensitiveLevel'
                    RegistryValue = @($property.RegistryValue | ForEach-Object { [string]$_ })
                }
            }

            $current = [string](@($property.RegistryValue)[0])
            if ($current -ne '80') {
                Set-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword 'RegROAMSensitiveLevel' -RegistryValue @('80') -NoRestart -Confirm:$false -ErrorAction Stop
                $changedCount++
                $messages += "Wi-Fi low-latency mode applied: $($adapter.Name) - minimized roaming scans"
            }
        } catch {
            $messages += "Skipped Wi-Fi low-latency setting: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterWifiLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalAdapterSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalAdapterSettings)) {
        try {
            Set-NetAdapterAdvancedProperty -Name $snapshot.Name -RegistryKeyword $snapshot.RegistryKeyword -RegistryValue @($snapshot.RegistryValue) -NoRestart -Confirm:$false -ErrorAction Stop
            $messages += "Wi-Fi setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore Wi-Fi setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalAdapterSettings = @()
    return $messages
}

function Set-BoosterEeeLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalEeeSettings' -DefaultValue @()
    $messages = @()
    $changedCount = 0

    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })

    foreach ($adapter in $adapters) {
        try {
            $property = Get-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword '*EEE' -ErrorAction Stop
            if ((Get-BoosterItemCount -Value $property) -lt 1) {
                continue
            }

            $alreadySaved = @($State.OriginalEeeSettings | Where-Object {
                $_.Name -eq $adapter.Name -and $_.RegistryKeyword -eq '*EEE'
            })
            if ((Get-BoosterItemCount -Value $alreadySaved) -lt 1) {
                $State.OriginalEeeSettings += [pscustomobject]@{
                    Name = [string]$adapter.Name
                    RegistryKeyword = '*EEE'
                    RegistryValue = @($property.RegistryValue | ForEach-Object { [string]$_ })
                }
            }

            $current = [string](@($property.RegistryValue)[0])
            if ($current -ne '0') {
                Set-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword '*EEE' -RegistryValue @('0') -NoRestart -Confirm:$false -ErrorAction Stop
                $changedCount++
                $messages += "Energy Efficient Ethernet (EEE) disabled: $($adapter.Name) - prevents momentary ping spikes/slowdowns"
            }
        } catch {
            $messages += "Skipped EEE setting: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterEeeLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalEeeSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalEeeSettings)) {
        try {
            Set-NetAdapterAdvancedProperty -Name $snapshot.Name -RegistryKeyword $snapshot.RegistryKeyword -RegistryValue @($snapshot.RegistryValue) -NoRestart -Confirm:$false -ErrorAction Stop
            $messages += "EEE setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore EEE setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalEeeSettings = @()
    return $messages
}

function Set-BoosterInterruptModerationLowLatency {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalInterruptModerationSettings' -DefaultValue @()
    $messages = @()
    $changedCount = 0

    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
    $keywords = @('*InterruptModeration', '*InterruptModerationRate')

    foreach ($adapter in $adapters) {
        foreach ($keyword in $keywords) {
            try {
                $property = Get-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword $keyword -ErrorAction Stop
                if ((Get-BoosterItemCount -Value $property) -lt 1) {
                    continue
                }

                $alreadySaved = @($State.OriginalInterruptModerationSettings | Where-Object {
                    $_.Name -eq $adapter.Name -and $_.RegistryKeyword -eq $keyword
                })
                if ((Get-BoosterItemCount -Value $alreadySaved) -lt 1) {
                    $State.OriginalInterruptModerationSettings += [pscustomobject]@{
                        Name = [string]$adapter.Name
                        RegistryKeyword = $keyword
                        RegistryValue = @($property.RegistryValue | ForEach-Object { [string]$_ })
                    }
                }

                $current = [string](@($property.RegistryValue)[0])
                if ($current -ne '0') {
                    Set-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword $keyword -RegistryValue @('0') -NoRestart -Confirm:$false -ErrorAction Stop
                    $changedCount++
                    $messages += "Interrupt moderation disabled: $($adapter.Name) - reduces packet processing delay/ping spikes"
                }

                break
            } catch {
                $messages += "Skipped interrupt moderation setting: $($adapter.Name) - $($_.Exception.Message)"
            }
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterInterruptModerationLowLatency {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalInterruptModerationSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalInterruptModerationSettings)) {
        try {
            Set-NetAdapterAdvancedProperty -Name $snapshot.Name -RegistryKeyword $snapshot.RegistryKeyword -RegistryValue @($snapshot.RegistryValue) -NoRestart -Confirm:$false -ErrorAction Stop
            $messages += "Interrupt moderation setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore interrupt moderation setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalInterruptModerationSettings = @()
    return $messages
}

function Set-BoosterQosPacketSchedulerEnabled {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalQosPacketSchedulerSettings' -DefaultValue @()
    $messages = @()
    $changedCount = 0

    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })

    foreach ($adapter in $adapters) {
        try {
            $binding = Get-NetAdapterBinding -Name $adapter.Name -ComponentID 'ms_pacer' -ErrorAction Stop

            $alreadySaved = @($State.OriginalQosPacketSchedulerSettings | Where-Object { $_.Name -eq $adapter.Name })
            if ((Get-BoosterItemCount -Value $alreadySaved) -lt 1) {
                $State.OriginalQosPacketSchedulerSettings += [pscustomobject]@{
                    Name = [string]$adapter.Name
                    Enabled = [bool]$binding.Enabled
                }
            }

            if (-not $binding.Enabled) {
                Enable-NetAdapterBinding -Name $adapter.Name -ComponentID 'ms_pacer' -ErrorAction Stop
                $changedCount++
                $messages += "QoS Packet Scheduler enabled: $($adapter.Name) - ensures game traffic prioritization actually works"
            }
        } catch {
            $messages += "Skipped QoS Packet Scheduler setting: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterQosPacketSchedulerEnabled {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalQosPacketSchedulerSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalQosPacketSchedulerSettings)) {
        try {
            if (-not $snapshot.Enabled) {
                Disable-NetAdapterBinding -Name $snapshot.Name -ComponentID 'ms_pacer' -ErrorAction Stop
                $messages += "QoS Packet Scheduler setting restored: $($snapshot.Name)"
            }
        } catch {
            $messages += "Failed to restore QoS Packet Scheduler setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalQosPacketSchedulerSettings = @()
    return $messages
}

function Set-BoosterFlowControlLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalFlowControlSettings' -DefaultValue @()
    $messages = @()
    $changedCount = 0

    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })

    foreach ($adapter in $adapters) {
        try {
            $property = Get-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword '*FlowControl' -ErrorAction Stop
            if ((Get-BoosterItemCount -Value $property) -lt 1) {
                continue
            }

            $alreadySaved = @($State.OriginalFlowControlSettings | Where-Object {
                $_.Name -eq $adapter.Name -and $_.RegistryKeyword -eq '*FlowControl'
            })
            if ((Get-BoosterItemCount -Value $alreadySaved) -lt 1) {
                $State.OriginalFlowControlSettings += [pscustomobject]@{
                    Name = [string]$adapter.Name
                    RegistryKeyword = '*FlowControl'
                    RegistryValue = @($property.RegistryValue | ForEach-Object { [string]$_ })
                }
            }

            $current = [string](@($property.RegistryValue)[0])
            if ($current -ne '0') {
                Set-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword '*FlowControl' -RegistryValue @('0') -NoRestart -Confirm:$false -ErrorAction Stop
                $changedCount++
                $messages += "Flow control disabled: $($adapter.Name) - reduces momentary lag from pause frames"
            }
        } catch {
            $messages += "Skipped flow control setting: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterFlowControlLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalFlowControlSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalFlowControlSettings)) {
        try {
            Set-NetAdapterAdvancedProperty -Name $snapshot.Name -RegistryKeyword $snapshot.RegistryKeyword -RegistryValue @($snapshot.RegistryValue) -NoRestart -Confirm:$false -ErrorAction Stop
            $messages += "Flow control setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore flow control setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalFlowControlSettings = @()
    return $messages
}

function Set-BoosterIPv4PreferenceMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalIPv6PreferenceSettings' -DefaultValue @()

    $path = 'HKLM:\SYSTEM\CurrentControlSet\Services\TCPIP6\Parameters'
    $name = 'DisabledComponents'
    $desired = [uint32]0x20

    if (-not (Test-Path -LiteralPath $path)) {
        throw "Could not find the IPv4 preference mode path: $path"
    }

    if ((Get-BoosterItemCount -Value $State.OriginalIPv6PreferenceSettings) -lt 1) {
        $State.OriginalIPv6PreferenceSettings = @(Get-BoosterRegistryValueSnapshot -Path $path -Name $name)
    }

    $snapshot = Get-BoosterRegistryValueSnapshot -Path $path -Name $name
    $current = ConvertTo-BoosterUInt32 -Value $snapshot.Value
    $messages = @()
    $changed = $false
    if ($current -ne $desired) {
        New-ItemProperty -LiteralPath $path -Name $name -Value $desired -PropertyType DWord -Force | Out-Null
        $changed = $true
        $messages += 'IPv4 preference mode applied: prefers IPv4 over an unstable IPv6 path in some networks, reducing ping spikes (a reboot may help it fully take effect)'
    }

    [pscustomobject]@{ Changed = $changed; Messages = $messages }
}

function Restore-BoosterIPv4PreferenceMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalIPv6PreferenceSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalIPv6PreferenceSettings)) {
        try {
            if ($snapshot.Existed) {
                New-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -Value $snapshot.Value -PropertyType DWord -Force | Out-Null
            } else {
                Remove-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -ErrorAction SilentlyContinue
            }
            $messages += 'IPv4 preference mode restored: IPv6 setting reverted'
        } catch {
            $messages += "Failed to restore IPv4 preference mode: $($_.Exception.Message)"
        }
    }

    $State.OriginalIPv6PreferenceSettings = @()
    return $messages
}

function Disable-BoosterSlowParallelAdapters {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State,
        [object]$Config
    )

    Ensure-BoosterStateProperty -State $State -Name 'DisabledNetworkAdapters' -DefaultValue @()
    $thresholdMbps = Get-BoosterConfigInt -Config $Config -Name 'slowParallelAdapterThresholdMbps' -Fallback 50
    if ($thresholdMbps -lt 1) {
        $thresholdMbps = 50
    }
    $thresholdBitsPerSecond = [uint64]$thresholdMbps * [uint64]1000000
    $messages = @()
    $changedCount = 0

    $defaultRoutes = @(Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue |
        Sort-Object @{ Expression = { [int]$_.RouteMetric + [int]$_.InterfaceMetric } })
    if ((Get-BoosterItemCount -Value $defaultRoutes) -lt 1) {
        return [pscustomobject]@{ Changed = $false; Messages = @() }
    }

    $primaryInterfaceIndex = [int]$defaultRoutes[0].InterfaceIndex
    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object {
        $_.Status -eq 'Up' -and
        [int]$_.ifIndex -ne $primaryInterfaceIndex -and
        [uint64]$_.ReceiveLinkSpeed -gt 0 -and
        [uint64]$_.ReceiveLinkSpeed -lt $thresholdBitsPerSecond
    })

    foreach ($adapter in $adapters) {
        $saved = @($State.DisabledNetworkAdapters | Where-Object { $_.Name -eq $adapter.Name })
        if ((Get-BoosterItemCount -Value $saved) -gt 0) {
            continue
        }

        try {
            Disable-NetAdapter -Name $adapter.Name -Confirm:$false -ErrorAction Stop
            $State.DisabledNetworkAdapters += [pscustomobject]@{ Name = [string]$adapter.Name }
            $changedCount++
            $speedMbps = [math]::Round(([double]$adapter.ReceiveLinkSpeed / 1000000), 1)
            $messages += "Turned off slow secondary connection: $($adapter.Name) ${speedMbps}Mbps"
        } catch {
            $messages += "Failed to clean up secondary connection: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterSlowParallelAdapters {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'DisabledNetworkAdapters' -DefaultValue @()
    $messages = @()
    foreach ($adapter in @(ConvertTo-BoosterArray $State.DisabledNetworkAdapters)) {
        try {
            Enable-NetAdapter -Name $adapter.Name -Confirm:$false -ErrorAction Stop
            $messages += "Secondary connection restored: $($adapter.Name)"
        } catch {
            $messages += "Failed to restore secondary connection: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    $State.DisabledNetworkAdapters = @()
    return $messages
}

function Set-BoosterGameQosPolicy {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ExecutablePath,
        [Parameter(Mandatory = $true)]
        [object]$State,
        [int]$DscpValue = 46
    )

    Ensure-BoosterStateProperty -State $State -Name 'GameQosPolicies' -DefaultValue @()
    if (-not $ExecutablePath) {
        return $null
    }

    $exeName = [System.IO.Path]::GetFileName($ExecutablePath)
    if (-not $exeName) {
        return $null
    }

    $safeName = [regex]::Replace([System.IO.Path]::GetFileNameWithoutExtension($exeName), '[^a-zA-Z0-9_-]', '_')
    $policyName = 'Booster-Game-' + $safeName
    $existingState = @($State.GameQosPolicies | Where-Object { $_.Name -eq $policyName })
    if ((Get-BoosterItemCount -Value $existingState) -gt 0) {
        return "Game network priority kept: $exeName"
    }

    try {
        Get-NetQosPolicy -PolicyStore ActiveStore -ErrorAction SilentlyContinue |
            Where-Object { $_ -and $_.PSObject.Properties['Name'] -and $_.Name -eq $policyName } |
            Remove-NetQosPolicy -PolicyStore ActiveStore -Confirm:$false -ErrorAction SilentlyContinue

        New-NetQosPolicy -Name $policyName -PolicyStore ActiveStore -AppPathNameMatchCondition $exeName -NetworkProfile All -DSCPAction ([sbyte]$DscpValue) -ErrorAction Stop | Out-Null
        $State.GameQosPolicies += [pscustomobject]@{ Name = $policyName; Store = 'ActiveStore' }
        return "Game network priority applied: $exeName (DSCP $DscpValue)"
    } catch {
        return "Game network priority failed: $exeName - $($_.Exception.Message)"
    }
}

function Remove-BoosterGameQosPolicies {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'GameQosPolicies' -DefaultValue @()
    $messages = @()
    foreach ($policy in @(ConvertTo-BoosterArray $State.GameQosPolicies)) {
        try {
            Remove-NetQosPolicy -Name $policy.Name -PolicyStore $policy.Store -Confirm:$false -ErrorAction Stop
            $messages += "Game network priority removed: $($policy.Name)"
        } catch {
            $messages += "Skipped removing game network priority: $($policy.Name)"
        }
    }

    $State.GameQosPolicies = @()
    return $messages
}

function Set-BoosterBackgroundNetworkQos {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State,
        [object]$Config
    )

    Ensure-BoosterStateProperty -State $State -Name 'BackgroundQosPolicies' -DefaultValue @()
    $processNames = @(Get-BoosterConfigArray -Config $Config -Name 'backgroundDownloadProcesses' -Fallback @(
        'OneDrive',
        'steam',
        'steamwebhelper',
        'EpicGamesLauncher',
        'GalaxyClient',
        'Battle.net',
        'EADesktop',
        'upc'
    ))
    $limitMbps = Get-BoosterConfigInt -Config $Config -Name 'backgroundDownloadLimitMbps' -Fallback 2
    if ($limitMbps -lt 1) {
        $limitMbps = 1
    }
    $limitBitsPerSecond = [uint64]$limitMbps * [uint64]1000000
    $messages = @()
    $changedCount = 0

    foreach ($configuredName in $processNames) {
        $processName = ([string]$configuredName).Trim()
        if ($processName.EndsWith('.exe', [System.StringComparison]::OrdinalIgnoreCase)) {
            $processName = $processName.Substring(0, $processName.Length - 4)
        }
        if (-not $processName) {
            continue
        }

        $paths = @()
        foreach ($process in @(Get-Process -Name $processName -ErrorAction SilentlyContinue)) {
            try {
                $path = Resolve-BoosterProcessPath -Process $process
                if ($path) {
                    $paths += [string]$path
                }
            } catch {
            }
        }

        foreach ($path in @($paths | Select-Object -Unique)) {
            $safeName = [regex]::Replace($processName, '[^a-zA-Z0-9_-]', '_')
            $policyName = 'Booster-Background-' + $safeName
            $alreadySaved = @($State.BackgroundQosPolicies | Where-Object { $_.Name -eq $policyName })
            if ((Get-BoosterItemCount -Value $alreadySaved) -gt 0) {
                continue
            }

            try {
                Get-NetQosPolicy -PolicyStore ActiveStore -ErrorAction SilentlyContinue |
                    Where-Object { $_ -and $_.PSObject.Properties['Name'] -and $_.Name -eq $policyName } |
                    Remove-NetQosPolicy -PolicyStore ActiveStore -Confirm:$false -ErrorAction SilentlyContinue

                New-NetQosPolicy -Name $policyName -PolicyStore ActiveStore -AppPathNameMatchCondition $path -NetworkProfile All -ThrottleRateActionBitsPerSecond $limitBitsPerSecond -ErrorAction Stop | Out-Null
                $State.BackgroundQosPolicies += [pscustomobject]@{ Name = $policyName; Store = 'ActiveStore' }
                $changedCount++
                $messages += "Background download throttled: $processName capped at ${limitMbps}Mbps"
            } catch {
                $messages += "Failed to throttle background download: $processName - $($_.Exception.Message)"
            }
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Remove-BoosterBackgroundNetworkQos {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'BackgroundQosPolicies' -DefaultValue @()
    $messages = @()
    foreach ($policy in @(ConvertTo-BoosterArray $State.BackgroundQosPolicies)) {
        try {
            Remove-NetQosPolicy -Name $policy.Name -PolicyStore $policy.Store -Confirm:$false -ErrorAction Stop
            $messages += "Background download throttle removed: $($policy.Name)"
        } catch {
            $messages += "Skipped removing background download throttle: $($policy.Name)"
        }
    }

    $State.BackgroundQosPolicies = @()
    return $messages
}

function Set-BoosterGamingDns {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State,
        [object]$Config
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalDnsSettings' -DefaultValue @()
    $configuredServers = @(Get-BoosterConfigArray -Config $Config -Name 'gamingDnsServers' -Fallback @('1.1.1.1', '1.0.0.1'))
    $dnsServers = @()
    foreach ($candidate in $configuredServers) {
        $parsedAddress = $null
        if ([System.Net.IPAddress]::TryParse([string]$candidate, [ref]$parsedAddress) -and
            $parsedAddress.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork) {
            $dnsServers += [string]$parsedAddress
        }
    }

    if ((Get-BoosterItemCount -Value $dnsServers) -lt 1) {
        $dnsServers = @('1.0.0.1', '1.1.1.1')
    }

    $messages = @()
    $changedCount = 0
    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
    foreach ($adapter in $adapters) {
        try {
            $current = Get-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -AddressFamily IPv4 -ErrorAction Stop
            $currentServers = @($current.ServerAddresses | ForEach-Object { [string]$_ } | Where-Object { $_ })
            $saved = @($State.OriginalDnsSettings | Where-Object { $_.InterfaceIndex -eq $adapter.InterfaceIndex })
            if ((Get-BoosterItemCount -Value $saved) -lt 1) {
                $interfaceKey = '{' + ([string]$adapter.InterfaceGuid).Trim('{}') + '}'
                $interfacePath = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\' + $interfaceKey
                $staticNameServer = ''
                if (Test-Path -LiteralPath $interfacePath) {
                    $staticNameServer = [string](Get-ItemPropertyValue -LiteralPath $interfacePath -Name 'NameServer' -ErrorAction SilentlyContinue)
                }

                $State.OriginalDnsSettings += [pscustomobject]@{
                    InterfaceIndex = [int]$adapter.InterfaceIndex
                    Name = [string]$adapter.Name
                    WasAutomatic = [string]::IsNullOrWhiteSpace($staticNameServer)
                    ServerAddresses = @($currentServers)
                }
            }

            $dnsNeedsChange = ((Get-BoosterItemCount -Value $currentServers) -ne (Get-BoosterItemCount -Value $dnsServers)) -or
                (($currentServers -join '|') -ne ($dnsServers -join '|'))
            if ($dnsNeedsChange) {
                Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ServerAddresses $dnsServers -ErrorAction Stop
                Clear-DnsClientCache -ErrorAction SilentlyContinue
                $changedCount++
                $messages += "Gaming DNS applied: $($adapter.Name) -> $($dnsServers -join ', ')"
            }
        } catch {
            $messages += "Skipped gaming DNS setting: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterGamingDns {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalDnsSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalDnsSettings)) {
        try {
            if ($snapshot.WasAutomatic) {
                Set-DnsClientServerAddress -InterfaceIndex $snapshot.InterfaceIndex -ResetServerAddresses -ErrorAction Stop
            } else {
                Set-DnsClientServerAddress -InterfaceIndex $snapshot.InterfaceIndex -ServerAddresses @($snapshot.ServerAddresses) -ErrorAction Stop
            }
            Clear-DnsClientCache -ErrorAction SilentlyContinue
            $messages += "DNS setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore DNS setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalDnsSettings = @()
    return $messages
}

function Set-BoosterRscLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalRscSettings' -DefaultValue @()
    $messages = @()
    $changedCount = 0
    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
    foreach ($adapter in $adapters) {
        try {
            $rsc = Get-NetAdapterRsc -Name $adapter.Name -ErrorAction Stop
            $saved = @($State.OriginalRscSettings | Where-Object { $_.Name -eq $adapter.Name })
            if ((Get-BoosterItemCount -Value $saved) -lt 1) {
                $State.OriginalRscSettings += [pscustomobject]@{
                    Name = [string]$adapter.Name
                    IPv4Enabled = [bool]$rsc.IPv4Enabled
                    IPv6Enabled = [bool]$rsc.IPv6Enabled
                }
            }

            if ($rsc.IPv4Enabled -or $rsc.IPv6Enabled) {
                Disable-NetAdapterRsc -Name $adapter.Name -IPv4 -IPv6 -NoRestart -Confirm:$false -ErrorAction Stop
                $changedCount++
                $messages += "Network latency minimization applied: $($adapter.Name) - disabled packet coalescing"
            }
        } catch {
            $messages += "Skipped network latency minimization: $($adapter.Name) - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterRscLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalRscSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalRscSettings)) {
        try {
            if ($snapshot.IPv4Enabled) {
                Enable-NetAdapterRsc -Name $snapshot.Name -IPv4 -NoRestart -Confirm:$false -ErrorAction Stop
            } else {
                Disable-NetAdapterRsc -Name $snapshot.Name -IPv4 -NoRestart -Confirm:$false -ErrorAction Stop
            }
            if ($snapshot.IPv6Enabled) {
                Enable-NetAdapterRsc -Name $snapshot.Name -IPv6 -NoRestart -Confirm:$false -ErrorAction Stop
            } else {
                Disable-NetAdapterRsc -Name $snapshot.Name -IPv6 -NoRestart -Confirm:$false -ErrorAction Stop
            }
            $messages += "Network packet setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore network packet setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalRscSettings = @()
    return $messages
}

function Set-BoosterTcpLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalTcpInterfaceSettings' -DefaultValue @()
    $targets = @(
        [pscustomobject]@{ Name = 'TcpAckFrequency'; Value = [uint32]1 },
        [pscustomobject]@{ Name = 'TCPNoDelay'; Value = [uint32]1 },
        [pscustomobject]@{ Name = 'TcpDelAckTicks'; Value = [uint32]0 }
    )
    $messages = @()
    $changedCount = 0
    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })

    foreach ($adapter in $adapters) {
        $interfaceKey = '{' + ([string]$adapter.InterfaceGuid).Trim('{}') + '}'
        $path = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\' + $interfaceKey
        if (-not (Test-Path -LiteralPath $path)) {
            continue
        }

        $adapterChanges = 0
        foreach ($target in $targets) {
            try {
                $saved = @($State.OriginalTcpInterfaceSettings | Where-Object {
                    $_.Path -eq $path -and $_.Name -eq $target.Name
                })
                if ((Get-BoosterItemCount -Value $saved) -lt 1) {
                    $State.OriginalTcpInterfaceSettings += Get-BoosterRegistryValueSnapshot -Path $path -Name $target.Name
                }

                $currentSnapshot = Get-BoosterRegistryValueSnapshot -Path $path -Name $target.Name
                $current = ConvertTo-BoosterUInt32 -Value $currentSnapshot.Value
                if ($current -ne $target.Value) {
                    New-ItemProperty -LiteralPath $path -Name $target.Name -Value $target.Value -PropertyType DWord -Force | Out-Null
                    $adapterChanges++
                    $changedCount++
                }
            } catch {
                $messages += "Skipped TCP low-latency setting: $($adapter.Name) $($target.Name) - $($_.Exception.Message)"
            }
        }

        if ($adapterChanges -gt 0) {
            $messages += "TCP low-latency mode applied: $($adapter.Name) - ${adapterChanges} change(s)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterTcpLowLatencyMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalTcpInterfaceSettings' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalTcpInterfaceSettings)) {
        try {
            if ($snapshot.Existed) {
                New-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -Value $snapshot.Value -PropertyType DWord -Force | Out-Null
            } else {
                Remove-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -ErrorAction SilentlyContinue
            }
            $messages += "TCP setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore TCP setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalTcpInterfaceSettings = @()
    return $messages
}

function Pause-BoosterBackgroundNetworkServices {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State,
        [object]$Config
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalNetworkServiceStates' -DefaultValue @()
    $serviceNames = @(Get-BoosterConfigArray -Config $Config -Name 'pauseBackgroundDownloadServices' -Fallback @('BITS', 'DoSvc'))
    $messages = @()
    $changedCount = 0
    foreach ($serviceName in $serviceNames) {
        try {
            $service = Get-Service -Name ([string]$serviceName) -ErrorAction Stop
            $saved = @($State.OriginalNetworkServiceStates | Where-Object { $_.Name -eq $service.Name })
            if ((Get-BoosterItemCount -Value $saved) -lt 1) {
                $State.OriginalNetworkServiceStates += [pscustomobject]@{
                    Name = [string]$service.Name
                    WasRunning = ($service.Status -eq 'Running')
                }
            }

            if ($service.Status -eq 'Running') {
                Stop-Service -Name $service.Name -Force -ErrorAction Stop
                $changedCount++
                $messages += "Background download paused: $($service.Name)"
            }
        } catch {
            $messages += "Skipped pausing background download: ${serviceName} - $($_.Exception.Message)"
        }
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterBackgroundNetworkServices {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalNetworkServiceStates' -DefaultValue @()
    $messages = @()
    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalNetworkServiceStates)) {
        if (-not $snapshot.WasRunning) {
            continue
        }

        try {
            $service = Get-Service -Name $snapshot.Name -ErrorAction Stop
            if ($service.Status -ne 'Running') {
                Start-Service -Name $snapshot.Name -ErrorAction Stop
                $messages += "Background download service restored: $($snapshot.Name)"
            }
        } catch {
            $messages += "Failed to restore background download service: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalNetworkServiceStates = @()
    return $messages
}

function Set-BoosterNetworkGamingMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State,
        [object]$Config
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalNetworkSettings' -DefaultValue @()
    Ensure-BoosterStateProperty -State $State -Name 'NetworkOptimized' -DefaultValue $false

    $path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
    $targets = @(
        [pscustomobject]@{ Name = 'NetworkThrottlingIndex'; Value = [uint32]::MaxValue },
        [pscustomobject]@{ Name = 'SystemResponsiveness'; Value = [uint32]10 }
    )

    if (-not (Test-Path -LiteralPath $path)) {
        throw "Could not find the network gaming mode path: $path"
    }

    if ((Get-BoosterItemCount -Value $State.OriginalNetworkSettings) -lt 1) {
        $snapshots = @()
        foreach ($target in $targets) {
            $snapshots += Get-BoosterRegistryValueSnapshot -Path $path -Name $target.Name
        }
        $State.OriginalNetworkSettings = $snapshots
    }

    $messages = @()
    $changedCount = 0
    foreach ($target in $targets) {
        $snapshot = Get-BoosterRegistryValueSnapshot -Path $path -Name $target.Name
        $current = ConvertTo-BoosterUInt32 -Value $snapshot.Value
        $desired = ConvertTo-BoosterUInt32 -Value $target.Value
        if ($current -ne $desired) {
            New-ItemProperty -LiteralPath $path -Name $target.Name -Value $target.Value -PropertyType DWord -Force | Out-Null
            $changedCount++
        }
    }

    $adapterChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'disableSlowParallelAdapters' -Fallback $true) {
        $adapterResult = Disable-BoosterSlowParallelAdapters -State $State -Config $Config
        $adapterChanged = [bool]$adapterResult.Changed
        $messages += $adapterResult.Messages
    }

    $wifiChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'wifiLowLatencyMode' -Fallback $true) {
        $wifiResult = Set-BoosterWifiLowLatencyMode -State $State
        $wifiChanged = [bool]$wifiResult.Changed
        $messages += $wifiResult.Messages
    }

    $eeeChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'disableEnergyEfficientEthernet' -Fallback $true) {
        $eeeResult = Set-BoosterEeeLowLatencyMode -State $State
        $eeeChanged = [bool]$eeeResult.Changed
        $messages += $eeeResult.Messages
    }

    $interruptModerationChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'disableInterruptModeration' -Fallback $true) {
        $interruptModerationResult = Set-BoosterInterruptModerationLowLatency -State $State
        $interruptModerationChanged = [bool]$interruptModerationResult.Changed
        $messages += $interruptModerationResult.Messages
    }

    $qosSchedulerChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'ensureQosPacketScheduler' -Fallback $true) {
        $qosSchedulerResult = Set-BoosterQosPacketSchedulerEnabled -State $State
        $qosSchedulerChanged = [bool]$qosSchedulerResult.Changed
        $messages += $qosSchedulerResult.Messages
    }

    $flowControlChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'disableFlowControl' -Fallback $true) {
        $flowControlResult = Set-BoosterFlowControlLowLatencyMode -State $State
        $flowControlChanged = [bool]$flowControlResult.Changed
        $messages += $flowControlResult.Messages
    }

    $ipv4PreferenceChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'preferIPv4ForGaming' -Fallback $true) {
        try {
            $ipv4Result = Set-BoosterIPv4PreferenceMode -State $State
            $ipv4PreferenceChanged = [bool]$ipv4Result.Changed
            $messages += $ipv4Result.Messages
        } catch {
            $messages += "Failed to apply IPv4 preference mode: $($_.Exception.Message)"
        }
    }

    $dnsChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'optimizeDnsForGaming' -Fallback $true) {
        $dnsResult = Set-BoosterGamingDns -State $State -Config $Config
        $dnsChanged = [bool]$dnsResult.Changed
        $messages += $dnsResult.Messages
    }

    $rscChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'disableRscForGaming' -Fallback $true) {
        $rscResult = Set-BoosterRscLowLatencyMode -State $State
        $rscChanged = [bool]$rscResult.Changed
        $messages += $rscResult.Messages
    }

    $servicesChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'pauseBackgroundNetworkDownloads' -Fallback $true) {
        $servicesResult = Pause-BoosterBackgroundNetworkServices -State $State -Config $Config
        $servicesChanged = [bool]$servicesResult.Changed
        $messages += $servicesResult.Messages
    }

    $tcpChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'tcpLowLatencyMode' -Fallback $true) {
        $tcpResult = Set-BoosterTcpLowLatencyMode -State $State
        $tcpChanged = [bool]$tcpResult.Changed
        $messages += $tcpResult.Messages
    }

    $backgroundQosChanged = $false
    if (Get-BoosterConfigBool -Config $Config -Name 'throttleBackgroundDownloads' -Fallback $true) {
        $backgroundQosResult = Set-BoosterBackgroundNetworkQos -State $State -Config $Config
        $backgroundQosChanged = [bool]$backgroundQosResult.Changed
        $messages += $backgroundQosResult.Messages
    }

    $State.NetworkOptimized = $true
    if ($changedCount -gt 0) {
        $messages += "Internet gaming mode applied: eased network throttling (${changedCount} change(s))"
    } else {
        $messages += 'Internet gaming mode kept: already optimized.'
    }

    [pscustomobject]@{
        Changed = (($changedCount -gt 0) -or $adapterChanged -or $wifiChanged -or $eeeChanged -or $interruptModerationChanged -or $qosSchedulerChanged -or $flowControlChanged -or $ipv4PreferenceChanged -or $dnsChanged -or $rscChanged -or $servicesChanged -or $tcpChanged -or $backgroundQosChanged)
        Applied = $true
        Messages = $messages
    }
}

function Restore-BoosterNetworkGamingMode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalNetworkSettings' -DefaultValue @()
    Ensure-BoosterStateProperty -State $State -Name 'NetworkOptimized' -DefaultValue $false

    $messages = @()
    $messages += Remove-BoosterBackgroundNetworkQos -State $State
    $messages += Restore-BoosterBackgroundNetworkServices -State $State
    $messages += Restore-BoosterTcpLowLatencyMode -State $State
    $messages += Restore-BoosterRscLowLatencyMode -State $State
    $messages += Restore-BoosterGamingDns -State $State
    $messages += Restore-BoosterEeeLowLatencyMode -State $State
    $messages += Restore-BoosterInterruptModerationLowLatency -State $State
    $messages += Restore-BoosterQosPacketSchedulerEnabled -State $State
    $messages += Restore-BoosterFlowControlLowLatencyMode -State $State
    $messages += Restore-BoosterIPv4PreferenceMode -State $State
    $messages += Restore-BoosterWifiLowLatencyMode -State $State
    $messages += Restore-BoosterSlowParallelAdapters -State $State

    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalNetworkSettings)) {
        try {
            if ($snapshot.Existed) {
                New-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -Value $snapshot.Value -PropertyType DWord -Force | Out-Null
                $messages += "Internet setting restored: $($snapshot.Name)"
            } else {
                Remove-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -ErrorAction SilentlyContinue
                $messages += "Internet setting removed on restore: $($snapshot.Name)"
            }
        } catch {
            $messages += "Failed to restore internet setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalNetworkSettings = @()
    $State.NetworkOptimized = $false
    return $messages
}

function Resolve-BoosterProcessPath {
    param(
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process]$Process
    )

    try {
        if ($Process.Path) {
            return $Process.Path
        }
    } catch {
    }

    try {
        return $Process.MainModule.FileName
    } catch {
        return $null
    }
}

function Set-BoosterGpuPreference {
    param(
        [string]$ExecutablePath,
        [ValidateSet('Default', 'PowerSaving', 'HighPerformance')]
        [string]$Preference = 'HighPerformance'
    )

    if (-not $ExecutablePath) {
        return [pscustomobject]@{
            Changed = $false
            Message = 'Skipped GPU preference setting: could not find the executable path.'
        }
    }

    $value = switch ($Preference) {
        'PowerSaving' { 'GpuPreference=1;' }
        'HighPerformance' { 'GpuPreference=2;' }
        default { 'GpuPreference=0;' }
    }

    $key = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    if (-not (Test-Path -LiteralPath $key)) {
        New-Item -Path $key -Force | Out-Null
    }

    New-ItemProperty -Path $key -Name $ExecutablePath -Value $value -PropertyType String -Force | Out-Null

    [pscustomobject]@{
        Changed = $true
        Message = "GPU preference changed to $Preference : $ExecutablePath"
    }
}

function Set-BoosterProcessPriority {
    param(
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process]$Process,
        [ValidateSet('Idle', 'BelowNormal', 'Normal', 'AboveNormal', 'High')]
        [string]$Priority = 'High'
    )

    $priorityValue = [System.Enum]::Parse([System.Diagnostics.ProcessPriorityClass], $Priority, $true)
    $Process.PriorityClass = $priorityValue
}

function Get-BoosterProcessStartKey {
    param(
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process]$Process
    )

    try {
        return $Process.StartTime.ToUniversalTime().ToString('o')
    } catch {
        return ''
    }
}

function Set-BoosterGameModeAndDvrOff {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalGameBarSettings' -DefaultValue @()

    $targets = @(
        [pscustomobject]@{ Path = 'HKCU:\System\GameConfigStore'; Name = 'GameDVR_Enabled'; Value = [uint32]0 },
        [pscustomobject]@{ Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name = 'AppCaptureEnabled'; Value = [uint32]0 },
        [pscustomobject]@{ Path = 'HKCU:\Software\Microsoft\GameBar'; Name = 'AutoGameModeEnabled'; Value = [uint32]1 },
        [pscustomobject]@{ Path = 'HKCU:\Software\Microsoft\GameBar'; Name = 'AllowAutoGameMode'; Value = [uint32]1 }
    )

    $messages = @()
    $changedCount = 0

    foreach ($target in $targets) {
        try {
            if (-not (Test-Path -LiteralPath $target.Path)) {
                New-Item -Path $target.Path -Force | Out-Null
            }

            $alreadySaved = @($State.OriginalGameBarSettings | Where-Object {
                $_.Path -eq $target.Path -and $_.Name -eq $target.Name
            })
            if ((Get-BoosterItemCount -Value $alreadySaved) -lt 1) {
                $State.OriginalGameBarSettings += Get-BoosterRegistryValueSnapshot -Path $target.Path -Name $target.Name
            }

            $snapshot = Get-BoosterRegistryValueSnapshot -Path $target.Path -Name $target.Name
            $current = ConvertTo-BoosterUInt32 -Value $snapshot.Value
            if ($current -ne $target.Value) {
                New-ItemProperty -LiteralPath $target.Path -Name $target.Name -Value $target.Value -PropertyType DWord -Force | Out-Null
                $changedCount++
            }
        } catch {
            $messages += "Skipped Game Mode/DVR setting: $($target.Name) - $($_.Exception.Message)"
        }
    }

    if ($changedCount -gt 0) {
        $messages += "Game Mode enabled + Game Bar background recording blocked: improves frame stability"
    }

    try {
        $presenceWriter = @(Get-Process -Name 'GameBarPresenceWriter' -ErrorAction SilentlyContinue)
        if ((Get-BoosterItemCount -Value $presenceWriter) -gt 0) {
            $presenceWriter | Stop-Process -Force -ErrorAction SilentlyContinue
            $messages += 'GameBarPresenceWriter process terminated: cleared Game Bar background recording resources (Windows will relaunch it automatically if needed)'
        }
    } catch {
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterGameModeAndDvrOff {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalGameBarSettings' -DefaultValue @()
    $messages = @()

    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalGameBarSettings)) {
        try {
            if ($snapshot.Existed) {
                New-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -Value $snapshot.Value -PropertyType DWord -Force | Out-Null
            } else {
                Remove-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -ErrorAction SilentlyContinue
            }
            $messages += "Game Mode/DVR setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore Game Mode/DVR setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    $State.OriginalGameBarSettings = @()
    return $messages
}

function Set-BoosterAnimationBoost {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalAnimationSettings' -DefaultValue @()

    $targets = @(
        [pscustomobject]@{ Path = 'HKCU:\Control Panel\Desktop\WindowMetrics'; Name = 'MinAnimate'; Value = '0'; Type = 'String' },
        [pscustomobject]@{ Path = 'HKCU:\Control Panel\Desktop'; Name = 'DragFullWindows'; Value = '0'; Type = 'String' },
        [pscustomobject]@{ Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name = 'TaskbarAnimations'; Value = [uint32]0; Type = 'DWord' },
        [pscustomobject]@{ Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name = 'ListviewAlphaSelect'; Value = [uint32]0; Type = 'DWord' },
        [pscustomobject]@{ Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name = 'ListviewShadow'; Value = [uint32]0; Type = 'DWord' }
    )

    $messages = @()
    $changedCount = 0

    foreach ($target in $targets) {
        try {
            if (-not (Test-Path -LiteralPath $target.Path)) {
                New-Item -Path $target.Path -Force | Out-Null
            }

            $alreadySaved = @($State.OriginalAnimationSettings | Where-Object {
                $_.Path -eq $target.Path -and $_.Name -eq $target.Name
            })
            if ((Get-BoosterItemCount -Value $alreadySaved) -lt 1) {
                $State.OriginalAnimationSettings += Get-BoosterRegistryValueSnapshot -Path $target.Path -Name $target.Name
            }

            $snapshot = Get-BoosterRegistryValueSnapshot -Path $target.Path -Name $target.Name
            $current = [string]$snapshot.Value
            $desired = [string]$target.Value
            if ($current -ne $desired) {
                New-ItemProperty -LiteralPath $target.Path -Name $target.Name -Value $target.Value -PropertyType $target.Type -Force | Out-Null
                $changedCount++
            }
        } catch {
            $messages += "Skipped Animation Boost setting: $($target.Name) - $($_.Exception.Message)"
        }
    }

    if ($changedCount -gt 0) {
        Send-BoosterUiSettingChangeBroadcast
        $messages += "Animation Boost applied: minimized window animation/shadow effects to free up resources (${changedCount} change(s))"
    }

    [pscustomobject]@{
        Changed = ($changedCount -gt 0)
        Messages = $messages
    }
}

function Restore-BoosterAnimationBoost {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    Ensure-BoosterStateProperty -State $State -Name 'OriginalAnimationSettings' -DefaultValue @()
    $messages = @()
    $restoredCount = 0

    foreach ($snapshot in @(ConvertTo-BoosterArray $State.OriginalAnimationSettings)) {
        try {
            if ($snapshot.Existed) {
                $propertyType = if ($snapshot.Value -is [string]) { 'String' } else { 'DWord' }
                New-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -Value $snapshot.Value -PropertyType $propertyType -Force | Out-Null
            } else {
                Remove-ItemProperty -LiteralPath $snapshot.Path -Name $snapshot.Name -ErrorAction SilentlyContinue
            }
            $restoredCount++
            $messages += "Animation Boost setting restored: $($snapshot.Name)"
        } catch {
            $messages += "Failed to restore Animation Boost setting: $($snapshot.Name) - $($_.Exception.Message)"
        }
    }

    if ($restoredCount -gt 0) {
        Send-BoosterUiSettingChangeBroadcast
    }

    $State.OriginalAnimationSettings = @()
    return $messages
}

function Set-BoosterBackgroundPriority {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Profile,
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    $messages = @()
    $lowerList = ConvertTo-BoosterArray (Get-BoosterPropertyValue -Object $Profile -Name 'lowerPriorityProcesses')
    $gameNames = @{}

    foreach ($rawName in (ConvertTo-BoosterArray (Get-BoosterPropertyValue -Object $Profile -Name 'processNames'))) {
        $normalized = Normalize-BoosterProcessName $rawName
        if ($normalized) {
            $gameNames[$normalized.ToLowerInvariant()] = $true
        }
    }

    foreach ($rawName in $lowerList) {
        $processName = Normalize-BoosterProcessName $rawName
        if (-not $processName) {
            continue
        }

        if ($gameNames.ContainsKey($processName.ToLowerInvariant())) {
            continue
        }

        foreach ($process in @(Get-Process -Name $processName -ErrorAction SilentlyContinue)) {
            try {
                $key = [string]$process.Id
                if (-not $State.LoweredPriorities.ContainsKey($key)) {
                    $State.LoweredPriorities[$key] = [pscustomobject]@{
                        Id = $process.Id
                        Name = $process.ProcessName
                        PriorityClass = $process.PriorityClass.ToString()
                        StartKey = Get-BoosterProcessStartKey -Process $process
                    }
                }

                $process.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::BelowNormal
                $messages += "Lowered priority: $($process.ProcessName) ($($process.Id))"
            } catch {
                $messages += "Failed to lower priority: $($process.ProcessName) ($($process.Id)) - $($_.Exception.Message)"
            }
        }
    }

    return $messages
}

function Restore-BoosterBackgroundPriority {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    $messages = @()
    foreach ($key in @($State.LoweredPriorities.Keys)) {
        $entry = $State.LoweredPriorities[$key]
        try {
            $process = Get-Process -Id $entry.Id -ErrorAction Stop
            if ((Get-BoosterProcessStartKey -Process $process) -eq $entry.StartKey) {
                $process.PriorityClass = [System.Enum]::Parse([System.Diagnostics.ProcessPriorityClass], $entry.PriorityClass, $true)
                $messages += "Background state restored: $($entry.Name) ($($entry.Id))"
            }
        } catch {
            $messages += "Skipped restoring background state: $($entry.Name) ($($entry.Id))"
        }
    }

    $State.LoweredPriorities = @{}
    return $messages
}

function Set-BoosterActiveProcessState {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State,
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process[]]$Processes
    )

    $State.ActiveProcessKeys = @{}
    foreach ($process in $Processes) {
        try {
            $State.ActiveProcessKeys[[string]$process.Id] = [pscustomobject]@{
                Id = $process.Id
                Name = $process.ProcessName
                StartKey = Get-BoosterProcessStartKey -Process $process
            }
        } catch {
        }
    }
}

function Test-BoosterActiveProcessesRunning {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    if (-not $State.Active) {
        return $false
    }

    foreach ($key in @($State.ActiveProcessKeys.Keys)) {
        $entry = $State.ActiveProcessKeys[$key]
        try {
            $process = Get-Process -Id $entry.Id -ErrorAction Stop
            if ((Get-BoosterProcessStartKey -Process $process) -eq $entry.StartKey) {
                return $true
            }
        } catch {
        }
    }

    return $false
}

function Close-BoosterConfiguredBackgroundProcesses {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Profile
    )

    $messages = @()
    foreach ($rawName in (ConvertTo-BoosterArray (Get-BoosterPropertyValue -Object $Profile -Name 'safeCloseProcesses'))) {
        $processName = Normalize-BoosterProcessName $rawName
        if (-not $processName) {
            continue
        }

        foreach ($process in @(Get-Process -Name $processName -ErrorAction SilentlyContinue)) {
            try {
                if ($process.MainWindowHandle -ne [IntPtr]::Zero) {
                    [void]$process.CloseMainWindow()
                    $messages += "Close requested: $($process.ProcessName) ($($process.Id))"
                } else {
                    $messages += "Not closing background app with no visible window: $($process.ProcessName) ($($process.Id))"
                }
            } catch {
                $messages += "Failed to close $($process.ProcessName) ($($process.Id)): $($_.Exception.Message)"
            }
        }
    }

    return $messages
}

function Get-BoosterSystemTier {
    $ramGb = 0
    $gpuGb = 0
    $logicalProcessors = 0

    try {
        $computer = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $ramGb = [math]::Round(($computer.TotalPhysicalMemory / 1GB), 1)
    } catch {
        try {
            $computer = Get-WmiObject Win32_ComputerSystem -ErrorAction Stop
            $ramGb = [math]::Round(($computer.TotalPhysicalMemory / 1GB), 1)
        } catch {
        }
    }

    try {
        $processor = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1
        $logicalProcessors = [int]$processor.NumberOfLogicalProcessors
    } catch {
        try {
            $processor = Get-WmiObject Win32_Processor -ErrorAction Stop | Select-Object -First 1
            $logicalProcessors = [int]$processor.NumberOfLogicalProcessors
        } catch {
        }
    }

    try {
        $video = @(Get-CimInstance Win32_VideoController -ErrorAction Stop)
    } catch {
        $video = @(Get-WmiObject Win32_VideoController -ErrorAction SilentlyContinue)
    }

    foreach ($adapter in $video) {
        try {
            if ($adapter.AdapterRAM -and $adapter.AdapterRAM -gt 0) {
                $candidate = [math]::Round(($adapter.AdapterRAM / 1GB), 1)
                if ($candidate -gt $gpuGb) {
                    $gpuGb = $candidate
                }
            }
        } catch {
        }
    }

    $tier = 'Balanced'
    if ($ramGb -ge 16 -and $gpuGb -ge 8 -and $logicalProcessors -ge 8) {
        $tier = 'Max'
    } elseif ($ramGb -ge 12 -and $gpuGb -ge 4 -and $logicalProcessors -ge 6) {
        $tier = 'High'
    }

    [pscustomobject]@{
        Tier = $tier
        RamGb = $ramGb
        GpuGb = $gpuGb
        LogicalProcessors = $logicalProcessors
    }
}

function Get-BoosterPrimaryDisplaySize {
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        return [pscustomobject]@{
            Width = [int]$bounds.Width
            Height = [int]$bounds.Height
        }
    } catch {
        return $null
    }
}

function Set-BoosterXmlValue {
    param(
        [Parameter(Mandatory = $true)]
        [xml]$Xml,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [string]$Value
    )

    $escapedName = $Name.Replace("'", "&apos;")
    $node = $Xml.SelectSingleNode("//*[local-name()='$escapedName']")
    if ($null -eq $node) {
        return $false
    }

    if ($node.InnerText -ne $Value) {
        $node.InnerText = $Value
        return $true
    }

    return $false
}

function Get-EldenRingGraphicsConfigPath {
    $appData = [Environment]::GetFolderPath('ApplicationData')
    if (-not $appData) {
        return $null
    }

    return (Join-Path $appData 'EldenRing\GraphicsConfig.xml')
}

function Get-BoosterEldenRingQualityMap {
    param(
        [string]$Mode,
        [object]$Tier
    )

    $selected = $Mode
    if (-not $selected -or $selected -eq 'AutoSafe') {
        $selected = $Tier.Tier
    }

    switch ($selected) {
        'Max' {
            return @{
                'QualitySetting' = 'CUSTOM'
                'Auto-detectBestRenderingSettings' = 'OFF'
                'TextureQuality' = 'MAX'
                'Antialiasing' = 'HIGH'
                'SSAO' = 'MAX'
                'DepthOfField' = 'HIGH'
                'MotionBlur' = 'OFF'
                'ShadowQuality' = 'HIGH'
                'LightingQuality' = 'MAX'
                'EffectsQuality' = 'MAX'
                'ReflectionQuality' = 'HIGH'
                'WaterSurfaceQuality' = 'HIGH'
                'ShaderQuality' = 'HIGH'
                'VolumetricEffectQuality' = 'HIGH'
                'RaytracingQuality' = 'OFF'
                'GrassQuality' = 'MAX'
                'GlobalIlluminationQuality' = 'HIGH'
            }
        }
        'High' {
            return @{
                'QualitySetting' = 'CUSTOM'
                'Auto-detectBestRenderingSettings' = 'OFF'
                'TextureQuality' = 'HIGH'
                'Antialiasing' = 'HIGH'
                'SSAO' = 'HIGH'
                'DepthOfField' = 'HIGH'
                'MotionBlur' = 'OFF'
                'ShadowQuality' = 'HIGH'
                'LightingQuality' = 'HIGH'
                'EffectsQuality' = 'HIGH'
                'ReflectionQuality' = 'HIGH'
                'WaterSurfaceQuality' = 'HIGH'
                'ShaderQuality' = 'HIGH'
                'VolumetricEffectQuality' = 'HIGH'
                'RaytracingQuality' = 'OFF'
                'GrassQuality' = 'HIGH'
                'GlobalIlluminationQuality' = 'HIGH'
            }
        }
        default {
            return @{
                'QualitySetting' = 'CUSTOM'
                'Auto-detectBestRenderingSettings' = 'OFF'
                'TextureQuality' = 'MEDIUM'
                'Antialiasing' = 'HIGH'
                'SSAO' = 'MEDIUM'
                'DepthOfField' = 'LOW'
                'MotionBlur' = 'OFF'
                'ShadowQuality' = 'MEDIUM'
                'LightingQuality' = 'MEDIUM'
                'EffectsQuality' = 'MEDIUM'
                'ReflectionQuality' = 'MEDIUM'
                'WaterSurfaceQuality' = 'HIGH'
                'ShaderQuality' = 'HIGH'
                'VolumetricEffectQuality' = 'MEDIUM'
                'RaytracingQuality' = 'OFF'
                'GrassQuality' = 'MEDIUM'
                'GlobalIlluminationQuality' = 'MEDIUM'
            }
        }
    }
}

function Set-EldenRingGraphicsProfile {
    param(
        [object]$Profile,
        [string]$ConfigPath,
        [string]$BackupDirectory
    )

    if (-not $ConfigPath) {
        $ConfigPath = Get-EldenRingGraphicsConfigPath
    }

    if (-not $ConfigPath -or -not (Test-Path -LiteralPath $ConfigPath)) {
        return [pscustomobject]@{
            Changed = $false
            Message = 'Could not find the Elden Ring graphics config file. Launch the game once, then try again.'
            Path = $ConfigPath
        }
    }

    if (-not $BackupDirectory) {
        $BackupDirectory = Join-Path (Get-BoosterRoot) 'backups'
    }

    if (-not (Test-Path -LiteralPath $BackupDirectory)) {
        New-Item -ItemType Directory -Path $BackupDirectory -Force | Out-Null
    }

    $xml = New-Object System.Xml.XmlDocument
    $xml.PreserveWhitespace = $true
    $xml.Load($ConfigPath)

    $tier = Get-BoosterSystemTier
    $graphics = Get-BoosterPropertyValue -Object $Profile -Name 'graphics'
    $graphicsMode = if ($graphics) { Get-BoosterPropertyValue -Object $graphics -Name 'mode' } else { $null }
    $mode = if ($graphicsMode) { [string]$graphicsMode } else { 'AutoSafe' }
    $qualityMap = Get-BoosterEldenRingQualityMap -Mode $mode -Tier $tier
    $changedCount = 0

    $preferFullscreen = if ($graphics) { [bool](Get-BoosterPropertyValue -Object $graphics -Name 'preferFullscreen') } else { $false }
    if ($preferFullscreen) {
        if (Set-BoosterXmlValue -Xml $xml -Name 'ScreenMode' -Value 'FULLSCREEN') {
            $changedCount++
        }
    }

    $preferNativeResolution = if ($graphics) { [bool](Get-BoosterPropertyValue -Object $graphics -Name 'preferNativeResolution') } else { $false }
    if ($preferNativeResolution) {
        $display = Get-BoosterPrimaryDisplaySize
        if ($display) {
            foreach ($name in @('Resolution-FullScreenWidth', 'Resolution-WindowScreenWidth')) {
                if (Set-BoosterXmlValue -Xml $xml -Name $name -Value ([string]$display.Width)) {
                    $changedCount++
                }
            }

            foreach ($name in @('Resolution-FullScreenHeight', 'Resolution-WindowScreenHeight')) {
                if (Set-BoosterXmlValue -Xml $xml -Name $name -Value ([string]$display.Height)) {
                    $changedCount++
                }
            }
        }
    }

    foreach ($key in $qualityMap.Keys) {
        if (Set-BoosterXmlValue -Xml $xml -Name $key -Value ([string]$qualityMap[$key])) {
            $changedCount++
        }
    }

    if ($changedCount -gt 0) {
        $backupName = 'GraphicsConfig-{0}.xml' -f (Get-Date -Format 'yyyyMMdd-HHmmss')
        $backupPath = Join-Path $BackupDirectory $backupName
        Copy-Item -LiteralPath $ConfigPath -Destination $backupPath -Force
        $xml.Save($ConfigPath)

        return [pscustomobject]@{
            Changed = $true
            Message = "Elden Ring graphics settings applied ($($tier.Tier), ${changedCount} change(s)). Backup: $backupPath"
            Path = $ConfigPath
            BackupPath = $backupPath
            Tier = $tier
        }
    }

    return [pscustomobject]@{
        Changed = $false
        Message = "Elden Ring graphics settings already match Booster's target ($($tier.Tier))."
        Path = $ConfigPath
        Tier = $tier
    }
}

function Start-BoosterSession {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [object]$Profile,
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process[]]$Processes,
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    $messages = @()
    $powerPlanChanged = $false
    $priorityCount = 0
    $gpuPreferenceCount = 0
    $backgroundLoweredCount = 0
    $graphicsChanged = $false
    $networkOptimized = $false
    $qosPolicyCount = 0

    if ($State.Active) {
        return [pscustomobject]@{
            Started = $false
            Messages = @('A boost is already active.')
            Summary = $State.LastSummary
        }
    }

    try {
        $power = Get-BoosterActivePowerScheme
        $State.OriginalPowerSchemeGuid = $power.Guid
        $State.OriginalPowerSchemeName = $power.Name
        $messages += "Saved current power plan: $($power.Raw)"
    } catch {
        $messages += "Failed to save current power plan: $($_.Exception.Message)"
    }

    try {
        $powerPlan = Get-BoosterPropertyValue -Object $Profile -Name 'powerPlan'
        if ($powerPlan -eq 'HighPerformance') {
            Set-BoosterPowerScheme -Scheme HighPerformance
            $powerPlanChanged = $true
            $messages += 'Switched power plan to High Performance.'
        }
    } catch {
        $messages += $_.Exception.Message
    }

    try {
        if (Get-BoosterConfigBool -Config $Config -Name 'optimizeNetworkForGaming' -Fallback $true) {
            $networkResult = Set-BoosterNetworkGamingMode -State $State -Config $Config
            $networkOptimized = [bool]$networkResult.Applied
            $messages += $networkResult.Messages
        }
    } catch {
        $messages += "Failed to apply internet gaming mode: $($_.Exception.Message)"
    }

    $profilePriority = Get-BoosterPropertyValue -Object $Profile -Name 'priority'
    $priority = if ($profilePriority) { [string]$profilePriority } else { 'High' }
    foreach ($process in $Processes) {
        try {
            Set-BoosterProcessPriority -Process $process -Priority $priority
            $priorityCount++
            $messages += "Game process state optimized: $($process.ProcessName) ($($process.Id))"
        } catch {
            $messages += "Failed to optimize game process state: $($process.ProcessName) ($($process.Id)) - $($_.Exception.Message)"
        }

        try {
            $exePath = Resolve-BoosterProcessPath -Process $process
            $profileGpuPreference = Get-BoosterPropertyValue -Object $Profile -Name 'gpuPreference'
            $preference = if ($profileGpuPreference) { [string]$profileGpuPreference } else { 'HighPerformance' }
            $gpuResult = Set-BoosterGpuPreference -ExecutablePath $exePath -Preference $preference
            if ($gpuResult.Changed) {
                $gpuPreferenceCount++
            }
            $messages += $gpuResult.Message
        } catch {
            $messages += "Failed to change GPU preference: $($_.Exception.Message)"
        }

        try {
            if (Get-BoosterConfigBool -Config $Config -Name 'prioritizeGameTraffic' -Fallback $true) {
                $qosPath = Resolve-BoosterProcessPath -Process $process
                $dscpValue = Get-BoosterConfigInt -Config $Config -Name 'gameTrafficDscp' -Fallback 46
                if ($dscpValue -lt 0 -or $dscpValue -gt 63) {
                    $dscpValue = 46
                }
                $qosMessage = Set-BoosterGameQosPolicy -ExecutablePath $qosPath -State $State -DscpValue $dscpValue
                if ($qosMessage) {
                    $messages += $qosMessage
                    if ($qosMessage -match 'applied|kept') {
                        $qosPolicyCount++
                    }
                }
            }
        } catch {
            $messages += "Game network priority failed: $($_.Exception.Message)"
        }
    }

    try {
        $profileName = Get-BoosterPropertyValue -Object $Profile -Name 'name'
        if ($Config.autoTuneGameGraphics -and $profileName -match 'Elden') {
            $graphicsResult = Set-EldenRingGraphicsProfile -Profile $Profile
            if ($graphicsResult.Changed) {
                $graphicsChanged = $true
            }
            $messages += $graphicsResult.Message
        }
    } catch {
        $messages += "Failed to adjust game graphics settings: $($_.Exception.Message)"
    }

    try {
        $backgroundMessages = @(Set-BoosterBackgroundPriority -Profile $Profile -State $State)
        $backgroundLoweredCount = @($backgroundMessages | Where-Object { [string]$_ -like 'Lowered priority:*' }).Count
        $messages += $backgroundMessages
    } catch {
        $messages += "Failed to lower background priority: $($_.Exception.Message)"
    }

    try {
        $messages += Close-BoosterConfiguredBackgroundProcesses -Profile $Profile
    } catch {
        $messages += "Failed to close configured background apps: $($_.Exception.Message)"
    }

    $gameModeChanged = $false
    try {
        if (Get-BoosterConfigBool -Config $Config -Name 'optimizeGameModeAndDvr' -Fallback $true) {
            $gameModeResult = Set-BoosterGameModeAndDvrOff -State $State
            $gameModeChanged = [bool]$gameModeResult.Changed
            $messages += $gameModeResult.Messages
        }
    } catch {
        $messages += "Failed to apply Game Mode/DVR setting: $($_.Exception.Message)"
    }

    $memoryFreedMb = 0
    try {
        if (Get-BoosterConfigBool -Config $Config -Name 'clearStandbyMemoryOnBoost' -Fallback $true) {
            $memoryResult = Clear-BoosterStandbyMemory
            if ($memoryResult.Success) {
                $memoryFreedMb = [int]$memoryResult.FreedMb
                $messages += "Standby memory cleared$(if ($memoryFreedMb -gt 0) { " (${memoryFreedMb}MB freed)" })"
            }
        }
    } catch {
        $messages += "Failed to clear standby memory: $($_.Exception.Message)"
    }

    $summaryParts = @()
    if ($powerPlanChanged) {
        $summaryParts += 'High-performance power'
    }
    if ($networkOptimized) {
        $summaryParts += 'Low-latency internet mode'
    }
    if ($qosPolicyCount -gt 0) {
        $summaryParts += 'Game traffic priority'
    }
    if ($gpuPreferenceCount -gt 0) {
        $summaryParts += "GPU high performance (${gpuPreferenceCount})"
    }
    if ($backgroundLoweredCount -gt 0) {
        $summaryParts += "Background cleanup (${backgroundLoweredCount})"
    }
    if ($graphicsChanged) {
        $summaryParts += 'Graphics settings applied'
    }
    if ($gameModeChanged) {
        $summaryParts += 'Game Mode + DVR blocked'
    }
    if ($memoryFreedMb -gt 0) {
        $summaryParts += "Memory freed (${memoryFreedMb}MB)"
    }

    $summary = if ((Get-BoosterItemCount -Value $summaryParts) -gt 0) {
        'Applied: {0}' -f ($summaryParts -join ', ')
    } else {
        'Applied: already optimized.'
    }
    $messages += $summary

    $State.Active = $true
    $State.ProfileId = Get-BoosterProfileKey -Profile $Profile
    $State.ProfileName = [string](Get-BoosterPropertyValue -Object $Profile -Name 'name')
    Set-BoosterActiveProcessState -State $State -Processes $Processes
    $State.LastSummary = $summary
    $State.StartedAt = Get-Date
    $State.LastMessages = $messages

    [pscustomobject]@{
        Started = $true
        Messages = $messages
        Summary = $summary
        PowerPlanChanged = $powerPlanChanged
        NetworkOptimized = $networkOptimized
        QosPolicyCount = $qosPolicyCount
        GpuPreferenceCount = $gpuPreferenceCount
        BackgroundLoweredCount = $backgroundLoweredCount
        GraphicsChanged = $graphicsChanged
        GameModeChanged = $gameModeChanged
        MemoryFreedMb = $memoryFreedMb
    }
}

function Update-BoosterSession {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [object]$Profile,
        [Parameter(Mandatory = $true)]
        [System.Diagnostics.Process[]]$Processes,
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    $messages = @()
    if (-not $State.Active) {
        return [pscustomobject]@{
            Refreshed = $false
            Messages = @('No boost is currently active.')
        }
    }

    try {
        $powerPlan = Get-BoosterPropertyValue -Object $Profile -Name 'powerPlan'
        if ($powerPlan -eq 'HighPerformance') {
            Set-BoosterPowerScheme -Scheme HighPerformance
        }
    } catch {
        $messages += "Failed to reapply power plan: $($_.Exception.Message)"
    }

    try {
        Ensure-BoosterStateProperty -State $State -Name 'NetworkOptimized' -DefaultValue $false
        if ((Get-BoosterConfigBool -Config $Config -Name 'optimizeNetworkForGaming' -Fallback $true) -and (-not $State.NetworkOptimized)) {
            $networkResult = Set-BoosterNetworkGamingMode -State $State -Config $Config
            $messages += $networkResult.Messages
        }
    } catch {
        $messages += "Failed to reapply internet gaming mode: $($_.Exception.Message)"
    }

    $profilePriority = Get-BoosterPropertyValue -Object $Profile -Name 'priority'
    $priority = if ($profilePriority) { [string]$profilePriority } else { 'High' }
    foreach ($process in $Processes) {
        try {
            Set-BoosterProcessPriority -Process $process -Priority $priority
        } catch {
            $messages += "Failed to reapply game process state: $($process.ProcessName) ($($process.Id)) - $($_.Exception.Message)"
        }

        try {
            $exePath = Resolve-BoosterProcessPath -Process $process
            $profileGpuPreference = Get-BoosterPropertyValue -Object $Profile -Name 'gpuPreference'
            $preference = if ($profileGpuPreference) { [string]$profileGpuPreference } else { 'HighPerformance' }
            [void](Set-BoosterGpuPreference -ExecutablePath $exePath -Preference $preference)
        } catch {
            $messages += "Failed to reapply GPU preference: $($_.Exception.Message)"
        }

        try {
            if (Get-BoosterConfigBool -Config $Config -Name 'prioritizeGameTraffic' -Fallback $true) {
                $qosPath = Resolve-BoosterProcessPath -Process $process
                $dscpValue = Get-BoosterConfigInt -Config $Config -Name 'gameTrafficDscp' -Fallback 46
                $qosMessage = Set-BoosterGameQosPolicy -ExecutablePath $qosPath -State $State -DscpValue $dscpValue
                if ($qosMessage) {
                    $messages += $qosMessage
                }
            }
        } catch {
            $messages += "Failed to reapply game network priority: $($_.Exception.Message)"
        }
    }

    try {
        [void](Set-BoosterBackgroundPriority -Profile $Profile -State $State)
    } catch {
        $messages += "Failed to reapply background cleanup: $($_.Exception.Message)"
    }

    try {
        if (Get-BoosterConfigBool -Config $Config -Name 'optimizeGameModeAndDvr' -Fallback $true) {
            $gameModeResult = Set-BoosterGameModeAndDvrOff -State $State
            $messages += $gameModeResult.Messages
        }
    } catch {
        $messages += "Failed to reapply Game Mode/DVR setting: $($_.Exception.Message)"
    }

    Set-BoosterActiveProcessState -State $State -Processes $Processes
    $State.ProfileId = Get-BoosterProfileKey -Profile $Profile
    $State.ProfileName = [string](Get-BoosterPropertyValue -Object $Profile -Name 'name')

    if ((Get-BoosterItemCount -Value $messages) -eq 0) {
        $messages += "Game detected again, optimization reapplied: $($State.ProfileName)"
    }

    [pscustomobject]@{
        Refreshed = $true
        Messages = $messages
    }
}

function Stop-BoosterSession {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    $messages = @()
    if (-not $State.Active) {
        return [pscustomobject]@{
            Stopped = $false
            Messages = @('No boost is currently active.')
        }
    }

    try {
        $messages += Restore-BoosterBackgroundPriority -State $State
    } catch {
        $messages += "Failed to restore background state: $($_.Exception.Message)"
    }

    try {
        $messages += Remove-BoosterGameQosPolicies -State $State
    } catch {
        $messages += "Failed to remove game network priority: $($_.Exception.Message)"
    }

    try {
        if (Get-BoosterConfigBool -Config $Config -Name 'restoreGameModeOnExit' -Fallback $true) {
            $messages += Restore-BoosterGameModeAndDvrOff -State $State
        }
    } catch {
        $messages += "Failed to restore Game Mode/DVR setting: $($_.Exception.Message)"
    }


    try {
        if (Get-BoosterConfigBool -Config $Config -Name 'restoreNetworkOnExit' -Fallback $true) {
            $messages += Restore-BoosterNetworkGamingMode -State $State
        }
    } catch {
        $messages += "Failed to restore internet setting: $($_.Exception.Message)"
    }

    try {
        if ($Config.restorePowerPlanOnExit -and $State.OriginalPowerSchemeGuid) {
            [void](Restore-BoosterPowerScheme -Guid $State.OriginalPowerSchemeGuid)
            $messages += "Power plan restored: $($State.OriginalPowerSchemeName) $($State.OriginalPowerSchemeGuid)"
        }
    } catch {
        $messages += "Failed to restore power plan: $($_.Exception.Message)"
    }

    $State.Active = $false
    $State.ProfileId = $null
    $State.ProfileName = $null
    $State.ActiveProcessKeys = @{}
    $State.LastSummary = $null
    $State.StartedAt = $null
    $State.OriginalPowerSchemeGuid = $null
    $State.OriginalPowerSchemeName = $null
    $State.OriginalNetworkSettings = @()
    $State.OriginalAdapterSettings = @()
    $State.OriginalDnsSettings = @()
    $State.OriginalRscSettings = @()
    $State.OriginalTcpInterfaceSettings = @()
    $State.OriginalNetworkServiceStates = @()
    $State.DisabledNetworkAdapters = @()
    $State.GameQosPolicies = @()
    $State.BackgroundQosPolicies = @()
    $State.NetworkOptimized = $false
    $State.LastMessages = $messages

    [pscustomobject]@{
        Stopped = $true
        Messages = $messages
    }
}

Export-ModuleMember -Function `
    Read-BoosterConfig, `
    New-BoosterState, `
    Find-BoosterProfile, `
    Get-BoosterProfileKey, `
    Get-BoosterProfileProcesses, `
    Get-BoosterWindowCandidates, `
    Get-BoosterForegroundWindowCandidate, `
    Get-BoosterRunningProfile, `
    Get-BoosterActivePowerScheme, `
    Get-BoosterSystemTier, `
    Set-EldenRingGraphicsProfile, `
    Start-BoosterSession, `
    Update-BoosterSession, `
    Test-BoosterActiveProcessesRunning, `
    Stop-BoosterSession, `
    Set-BoosterAnimationBoost, `
    Restore-BoosterAnimationBoost, `
    Clear-BoosterStandbyMemory, `
    Invoke-BoosterRouteTrace, `
    Get-BoosterRouteDiagnosisSummary


















